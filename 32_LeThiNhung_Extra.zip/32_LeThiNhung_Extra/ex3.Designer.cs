﻿namespace _32_LeThiNhung_Extra
{
    partial class ex3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbMusic = new System.Windows.Forms.CheckBox();
            this.cbWatch = new System.Windows.Forms.CheckBox();
            this.cbGame = new System.Windows.Forms.CheckBox();
            this.cbShopping = new System.Windows.Forms.CheckBox();
            this.cbVisit = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbRed = new System.Windows.Forms.RadioButton();
            this.rbWhite = new System.Windows.Forms.RadioButton();
            this.rbYellow = new System.Windows.Forms.RadioButton();
            this.rbPink = new System.Windows.Forms.RadioButton();
            this.rbBlue = new System.Windows.Forms.RadioButton();
            this.btnFavor = new System.Windows.Forms.Button();
            this.btnColor = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbVisit);
            this.groupBox1.Controls.Add(this.cbShopping);
            this.groupBox1.Controls.Add(this.cbGame);
            this.groupBox1.Controls.Add(this.cbWatch);
            this.groupBox1.Controls.Add(this.cbMusic);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 277);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Your favor";
            // 
            // cbMusic
            // 
            this.cbMusic.AutoSize = true;
            this.cbMusic.Location = new System.Drawing.Point(6, 45);
            this.cbMusic.Name = "cbMusic";
            this.cbMusic.Size = new System.Drawing.Size(161, 24);
            this.cbMusic.TabIndex = 1;
            this.cbMusic.Text = "Listen to music";
            this.cbMusic.UseVisualStyleBackColor = true;
            // 
            // cbWatch
            // 
            this.cbWatch.AutoSize = true;
            this.cbWatch.Location = new System.Drawing.Point(6, 90);
            this.cbWatch.Name = "cbWatch";
            this.cbWatch.Size = new System.Drawing.Size(113, 24);
            this.cbWatch.TabIndex = 2;
            this.cbWatch.Text = "Watch TV";
            this.cbWatch.UseVisualStyleBackColor = true;
            // 
            // cbGame
            // 
            this.cbGame.AutoSize = true;
            this.cbGame.Location = new System.Drawing.Point(6, 135);
            this.cbGame.Name = "cbGame";
            this.cbGame.Size = new System.Drawing.Size(118, 24);
            this.cbGame.TabIndex = 3;
            this.cbGame.Text = "Play game";
            this.cbGame.UseVisualStyleBackColor = true;
            // 
            // cbShopping
            // 
            this.cbShopping.AutoSize = true;
            this.cbShopping.Location = new System.Drawing.Point(6, 184);
            this.cbShopping.Name = "cbShopping";
            this.cbShopping.Size = new System.Drawing.Size(108, 24);
            this.cbShopping.TabIndex = 4;
            this.cbShopping.Text = "Shopping";
            this.cbShopping.UseVisualStyleBackColor = true;
            // 
            // cbVisit
            // 
            this.cbVisit.AutoSize = true;
            this.cbVisit.Location = new System.Drawing.Point(6, 227);
            this.cbVisit.Name = "cbVisit";
            this.cbVisit.Size = new System.Drawing.Size(69, 24);
            this.cbVisit.TabIndex = 5;
            this.cbVisit.Text = "Visit";
            this.cbVisit.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbBlue);
            this.groupBox2.Controls.Add(this.rbPink);
            this.groupBox2.Controls.Add(this.rbYellow);
            this.groupBox2.Controls.Add(this.rbWhite);
            this.groupBox2.Controls.Add(this.rbRed);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(270, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 277);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Your color you like";
            // 
            // rbRed
            // 
            this.rbRed.AutoSize = true;
            this.rbRed.Location = new System.Drawing.Point(6, 45);
            this.rbRed.Name = "rbRed";
            this.rbRed.Size = new System.Drawing.Size(63, 24);
            this.rbRed.TabIndex = 0;
            this.rbRed.TabStop = true;
            this.rbRed.Text = "Red";
            this.rbRed.UseVisualStyleBackColor = true;
            // 
            // rbWhite
            // 
            this.rbWhite.AutoSize = true;
            this.rbWhite.Location = new System.Drawing.Point(6, 89);
            this.rbWhite.Name = "rbWhite";
            this.rbWhite.Size = new System.Drawing.Size(78, 24);
            this.rbWhite.TabIndex = 1;
            this.rbWhite.TabStop = true;
            this.rbWhite.Text = "White";
            this.rbWhite.UseVisualStyleBackColor = true;
            // 
            // rbYellow
            // 
            this.rbYellow.AutoSize = true;
            this.rbYellow.Location = new System.Drawing.Point(6, 135);
            this.rbYellow.Name = "rbYellow";
            this.rbYellow.Size = new System.Drawing.Size(84, 24);
            this.rbYellow.TabIndex = 2;
            this.rbYellow.TabStop = true;
            this.rbYellow.Text = "Yellow";
            this.rbYellow.UseVisualStyleBackColor = true;
            // 
            // rbPink
            // 
            this.rbPink.AutoSize = true;
            this.rbPink.Location = new System.Drawing.Point(6, 184);
            this.rbPink.Name = "rbPink";
            this.rbPink.Size = new System.Drawing.Size(66, 24);
            this.rbPink.TabIndex = 3;
            this.rbPink.TabStop = true;
            this.rbPink.Text = "Pink";
            this.rbPink.UseVisualStyleBackColor = true;
            // 
            // rbBlue
            // 
            this.rbBlue.AutoSize = true;
            this.rbBlue.Location = new System.Drawing.Point(6, 227);
            this.rbBlue.Name = "rbBlue";
            this.rbBlue.Size = new System.Drawing.Size(68, 24);
            this.rbBlue.TabIndex = 4;
            this.rbBlue.TabStop = true;
            this.rbBlue.Text = "Blue";
            this.rbBlue.UseVisualStyleBackColor = true;
            // 
            // btnFavor
            // 
            this.btnFavor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFavor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFavor.Location = new System.Drawing.Point(11, 296);
            this.btnFavor.Name = "btnFavor";
            this.btnFavor.Size = new System.Drawing.Size(201, 33);
            this.btnFavor.TabIndex = 7;
            this.btnFavor.Text = "Your Favor";
            this.btnFavor.UseVisualStyleBackColor = true;
            this.btnFavor.Click += new System.EventHandler(this.btnFavor_Click);
            // 
            // btnColor
            // 
            this.btnColor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColor.Location = new System.Drawing.Point(260, 296);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(201, 33);
            this.btnColor.TabIndex = 8;
            this.btnColor.Text = "Your Color";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // ex3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(482, 353);
            this.Controls.Add(this.btnColor);
            this.Controls.Add(this.btnFavor);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ex3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ex3";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbVisit;
        private System.Windows.Forms.CheckBox cbShopping;
        private System.Windows.Forms.CheckBox cbGame;
        private System.Windows.Forms.CheckBox cbWatch;
        private System.Windows.Forms.CheckBox cbMusic;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbBlue;
        private System.Windows.Forms.RadioButton rbPink;
        private System.Windows.Forms.RadioButton rbYellow;
        private System.Windows.Forms.RadioButton rbWhite;
        private System.Windows.Forms.RadioButton rbRed;
        private System.Windows.Forms.Button btnFavor;
        private System.Windows.Forms.Button btnColor;
    }
}